#include "rclcpp/rclcpp.hpp"
#include "autoware_auto_planning_msgs/msg/trajectory.hpp"
#include "autoware_auto_planning_msgs/msg/trajectory_point.hpp"
#include "builtin_interfaces/msg/duration.hpp"
#include "geometry_msgs/msg/pose.hpp"

#include <fstream>
#include <sstream>
#include <string>
#include <vector>
// #include <filesystem>

class CsvToTrajectoryNode : public rclcpp::Node
{
public:
  CsvToTrajectoryNode() : Node("csv_to_trajectory_node"), has_published_(false)
  {
    publisher_ = this->create_publisher<autoware_auto_planning_msgs::msg::Trajectory>(
      "/planning/scenario_planning/trajectory", 10);

    std::string home_dir = std::getenv("HOME");
    csv_file_path_ = home_dir + "/trajectory_output_2.csv";

    if (!read_csv_to_trajectory(csv_file_path_)) {
      RCLCPP_ERROR(this->get_logger(), "Failed to read trajectory from CSV.");
    }

    timer_ = this->create_wall_timer(std::chrono::milliseconds(100),
                                     std::bind(&CsvToTrajectoryNode::publish_trajectory, this));
  }

private:
  bool read_csv_to_trajectory(const std::string & file_path)
  {
    std::ifstream file(file_path);
    if (!file.is_open()) {
      RCLCPP_ERROR(this->get_logger(), "Unable to open CSV file: %s", file_path.c_str());
      return false;
    }

    std::string line;
    std::getline(file, line);  // Skip header line

    while (std::getline(file, line)) {
      std::stringstream ss(line);
      std::string cell;
      std::vector<double> values;

      while (std::getline(ss, cell, ',')) {
        values.push_back(std::stod(cell));
      }

      if (values.size() < 11) continue;

      autoware_auto_planning_msgs::msg::TrajectoryPoint tp;
      tp.pose.position.x = values[0];
      tp.pose.position.y = values[1];
      tp.pose.position.z = values[2];
      tp.pose.orientation.x = values[3];
      tp.pose.orientation.y = values[4];
      tp.pose.orientation.z = values[5];
      tp.pose.orientation.w = values[6];
      tp.longitudinal_velocity_mps = values[7];
      tp.acceleration_mps2 = values[10];
      tp.lateral_velocity_mps = values[8];
      tp.heading_rate_rps = values[9];
      tp.front_wheel_angle_rad = 0.0;
      tp.rear_wheel_angle_rad = 0.0;
      tp.time_from_start = builtin_interfaces::msg::Duration();

      trajectory_.points.push_back(tp);
    }

    trajectory_.header.frame_id = "map";
    return true;
  }

  void publish_trajectory()
  {
    // if (!has_published_) {
      trajectory_.header.stamp = this->get_clock()->now();
      publisher_->publish(trajectory_);
      RCLCPP_INFO(this->get_logger(), "Published trajectory with %ld points.", trajectory_.points.size());
      has_published_ = true;
    // }
  }

  std::string csv_file_path_;
  bool has_published_;
  autoware_auto_planning_msgs::msg::Trajectory trajectory_;
  rclcpp::Publisher<autoware_auto_planning_msgs::msg::Trajectory>::SharedPtr publisher_;
  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<CsvToTrajectoryNode>());
  rclcpp::shutdown();
  return 0;
}
